package com.wz.bean;

public class ExpectMovie_Bean {
	private int id;
	private String title;
	private String director;
	private String actor ;
	private String duration;
	private String img;
	private String type;
	private String contry;
	private String evaluate;
	private String time;
	private int people;
	public int getPeople() {
		return people;
	}
	public void setPeople(int people) {
		this.people = people;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getDirector() {
		return director;
	}
	public void setDirector(String director) {
		this.director = director;
	}
	public String getActor() {
		return actor;
	}
	public void setActor(String actor) {
		this.actor = actor;
	}
	public String getDuration() {
		return duration;
	}
	public void setDuration(String dyration) {
		this.duration = dyration;
	}
	public String getImg() {
		return img;
	}
	public void setImg(String img) {
		this.img = img;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getContry() {
		return contry;
	}
	public void setContry(String contry) {
		this.contry = contry;
	}
	public String getEvaluate() {
		return evaluate;
	}
	public void setEvaluate(String evaluate) {
		this.evaluate = evaluate;
	}
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}
	@Override
	public String toString() {
		return "ExpectMovie_Bean [id=" + id + ", title=" + title + ", director=" + director + ", actor=" + actor
				+ ", dyration=" + duration + ", img=" + img + ", type=" + type + ", contry=" + contry + ", evaluate="
				+ evaluate + ", time=" + time + "]";
	}
	
}
