package com.wz.bean;

public class User_Bean {
	private String count;
	private String passward;
	public String getCount() {
		return count;
	}
	public void setCount(String count) {
		this.count = count;
	}
	public String getPassward() {
		return passward;
	}
	public void setPassward(String passward) {
		this.passward = passward;
	}
	@Override
	public String toString() {
		return "User_Bean [count=" + count + ", passward=" + passward + "]";
	}
}
