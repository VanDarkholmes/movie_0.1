package com.wz.bean;

public class Movie_Bean {
	private int id;
	private String title;
	private String director;
	private String actor;
	private String img;
	private String type;
	private String contry;
	private String evaluate;
	private int cost;
	private double score;
	private String cinitype;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getDirector() {
		return director;
	}
	public void setDirector(String director) {
		this.director = director;
	}
	public String getActor() {
		return actor;
	}
	public void setActor(String actor) {
		this.actor = actor;
	}
	public String getImg() {
		return img;
	}
	public void setImg(String img) {
		this.img = img;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getContry() {
		return contry;
	}
	public void setContry(String contry) {
		this.contry = contry;
	}
	public String getEvaluate() {
		return evaluate;
	}
	public void setEvaluate(String evaluate) {
		this.evaluate = evaluate;
	}
	public int getCost() {
		return cost;
	}
	public void setCost(int cost) {
		this.cost = cost;
	}
	public double getScore() {
		return score;
	}
	public void setScore(double score) {
		this.score = score;
	}
	
	public String getCinitype() {
		return cinitype;
	}
	public void setCinitype(String cinitype) {
		this.cinitype = cinitype;
	}
	@Override
	public String toString() {
		return "Movie_Bean [id=" + id + ", title=" + title + ", director=" + director + ", actor=" + actor + ", img="
				+ img + ", type=" + type + ", contry=" + contry + ", evaluate=" + evaluate + ", cost=" + cost
				+ ", score=" + score + "]";
	}
	
}
