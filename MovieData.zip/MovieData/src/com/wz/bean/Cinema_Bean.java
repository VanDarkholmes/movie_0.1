package com.wz.bean;

public class Cinema_Bean {
	public String name;
	public int mainid;
	public int id;
	public String video_room;
	public String time;
	
	public String seat;
	
	public int getMainid() {
		return mainid;
	}
	public void setMainid(int mainid) {
		this.mainid = mainid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getVideo_room() {
		return video_room;
	}
	public void setVideo_room(String video_room) {
		this.video_room = video_room;
	}
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}
	
	public String getSeat() {
		return seat;
	}
	public void setSeat(String seat) {
		this.seat = seat;
	}
	
}
