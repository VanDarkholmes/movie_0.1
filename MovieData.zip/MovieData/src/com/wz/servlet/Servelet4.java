package com.wz.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.wz.bean.ExpectMovie_Bean;
import com.wz.bean.Movie_Bean;
import com.wz.dao.ExpectMovieDao;
import com.wz.dao.HotMovieDao;
import com.wz.dao.MovieDao;
import com.wz.jdbc.DataConnerction;

/**
 * Servlet implementation class Servelet4
 */
@WebServlet("/Servelet4")
public class Servelet4 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Servelet4() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request,response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setHeader("Access-Control-Allow-Origin", "*");
		 response.setContentType("text/javascript");
		DataConnerction con = new DataConnerction();
		HotMovieDao hot = new HotMovieDao(con);
		ExpectMovieDao expe = new ExpectMovieDao(con);
		MovieDao mvdao = new MovieDao(con);
		List<Movie_Bean> hotlist=new ArrayList<Movie_Bean>();
		List<ExpectMovie_Bean> expelist = new ArrayList<ExpectMovie_Bean>();
		JSONObject obj = new  JSONObject();
		String []types = {"全部","爱情","喜剧","动画","剧情","恐怖","惊悚","科幻","动作","悬疑","犯罪","冒险","战争","奇幻","运动","家庭","古装","武侠"
				,"西部","历史","传记"};
		String []contrys = {"全部","大陆","美国","韩国","日本","香港","台湾","泰国","印度","法国"};
		String showType = request.getParameter("showType");  //表示要显示的属性		
		String type = null;
		String contry = null;
		String page = null;
		if(request.getParameter("type")!=null) {
			type=types[Integer.parseInt(request.getParameter("type"))];
			if(Integer.parseInt(request.getParameter("type"))==0) {
				type = null;
			}
		}
		if(request.getParameter("contry")!=null) {
			contry=contrys[Integer.parseInt(request.getParameter("contry"))];
			if(Integer.parseInt(request.getParameter("contry"))==0) {
				contry = null;
			}
		}	
		if(request.getParameter("page")!=null) {
			page = request.getParameter("page");
		}else {
			page="1";
		}
//		String type = request.getParameter("type");
//				 Integer.parseInt(request.getParameter("type"));
//		String contry = request.getParameter("contry");
		
		if("2".equals(showType)) {
			expelist=expe.getExpect(type, contry,page);
			obj.put("count", expe.getExpect(type,contry,null).size());
			obj.put("showType", "2");
			obj.put("type",request.getParameter("type"));
			obj.put("contry",request.getParameter("contry"));
			obj.put("movie",JSONArray.toJSON(expelist));
		}else if("3".equals(showType)) {
			hotlist=mvdao.getMovie(type, contry,page);
			obj.put("count", mvdao.getMovie(type, contry,null).size());
			obj.put("showType", "3");	
			obj.put("type",request.getParameter("type"));
			obj.put("contry",request.getParameter("contry"));
			obj.put("movie",JSONArray.toJSON(hotlist));
		}else {
			hotlist=hot.getHotMovie(type, contry,page);			
			obj.put("count", hot.getHotMovie(type,contry,null).size());
			obj.put("showType", "1");
			obj.put("type",request.getParameter("type"));
			obj.put("contry",request.getParameter("contry"));
			obj.put("movie",JSONArray.toJSON(hotlist));
		}
		obj.put("page",page);
		
		response.setCharacterEncoding("gbk");
		PrintWriter out = response.getWriter();
		out.print(obj);
		out.close();		
	}

}
