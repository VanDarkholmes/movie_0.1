package com.wz.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.wz.dao.UserDao;
import com.wz.jdbc.DataConnerction;
import com.wz.session.MySessionContext;
import com.wz.session.MySessionListener;

/**
 * Servlet implementation class Servelet2
 */
@WebServlet("/Servelet2")
public class Servelet2 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Servelet2() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request,response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	//登陆页面
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setHeader("Access-Control-Allow-Origin", "*");
//		response.setContentType("text/javascript");	
		DataConnerction con = new DataConnerction();
		UserDao us = new UserDao(con);
		String user = request.getParameter("user");
		String password = request.getParameter("password");
		JSONObject obj = new  JSONObject();
		HttpSession session=request.getSession(); 
		
		MySessionContext.AddSession(session);
		boolean flage = false;
		try {
			 flage = us.findUser(user, password);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if(flage) {
			obj.put("flage", flage);
			obj.put("count", user);
			obj.put("password",password);
			obj.put("sessionID",session.getId());
			session.setAttribute("user", user);
			session.setAttribute("password", password);		
		}else {
			obj.put("flage", false);
		}
		response.setCharacterEncoding("gbk");
		PrintWriter out = response.getWriter();
		out.print(obj);
		out.close();		
	}

}
