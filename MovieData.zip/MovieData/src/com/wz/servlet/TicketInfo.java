package com.wz.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.alibaba.fastjson.JSONObject;
import com.wz.bean.Cinema_Bean;
import com.wz.bean.Movie_Bean;
import com.wz.dao.CinemaDao;
import com.wz.dao.MovieDao;
import com.wz.jdbc.DataConnerction;

/**
 * Servlet implementation class TicketInfo
 */
@WebServlet("/TicketInfo")
public class TicketInfo extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public TicketInfo() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	
		 response.setHeader("Access-Control-Allow-Origin", "*");
		 response.setContentType("text/javascript");	
		 DataConnerction con = new DataConnerction();
		 MovieDao mvdao = new MovieDao(con);
		 CinemaDao cinema = new CinemaDao(con);
		 Movie_Bean mv = new Movie_Bean();
		 Cinema_Bean cibean = new Cinema_Bean();
		 JSONObject obj = new  JSONObject();
		 Cinema_Bean seat = new  Cinema_Bean();
		 String mvid = request.getParameter("mvid");
		 if(mvid!=null) {
			 mv= mvdao.getMoInfo(mvid);
			 obj.put("movie", JSONObject.toJSON(mv));
		 }			 
		 String cinemaid = request.getParameter("cinemaid");
		 if(cinemaid!=null) {
			 seat=cinema.getSeat(cinemaid);		
			 obj.put("seat", seat);
		 }
		 String room=request.getParameter("room");
		 if(room!=null) {
			 cibean = cinema.getCinema1(room);
			
			 obj.put("room", JSONObject.toJSON(cibean));
		 }
		response.setCharacterEncoding("gbk");
		PrintWriter out = response.getWriter();
		out.print(obj);
		out.close();	
			 	
		 
	}

}
