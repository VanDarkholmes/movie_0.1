package com.wz.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.wz.bean.ExpectMovie_Bean;
import com.wz.bean.Movie_Bean;
import com.wz.dao.ExpectMovieDao;
import com.wz.dao.HotMovieDao;
import com.wz.jdbc.DataConnerction;
import com.wz.session.MySessionContext;

/**
 * Servlet implementation class Servelet1
 */
@WebServlet("/Servelet1")
public class Servelet1 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Servelet1() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	//首页信息
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub		
		 response.setHeader("Access-Control-Allow-Origin", "*");
		 response.setContentType("text/javascript");	
	       
		String flage = request.getParameter("flage");
		
		DataConnerction con = new DataConnerction();
		HotMovieDao Hot= new HotMovieDao(con);
		ExpectMovieDao expect = new ExpectMovieDao(con);
		
		List<Movie_Bean> hotlist = new ArrayList<Movie_Bean>();
		List<ExpectMovie_Bean> expectli = new ArrayList<ExpectMovie_Bean>();
		List<ExpectMovie_Bean> expectrank = new ArrayList<ExpectMovie_Bean>();
		
//		HttpSession session=MySessionContext.getSession(request.getParameter("sessionID"));

		JSONObject obj = new  JSONObject();
		//判断是否登陆 
		if("true".equals(flage)) {
			obj.put("flage", flage);

		}		
		hotlist = Hot.GetHotAll();
		expectli = expect.GetExpectAll();
		expectrank = expect.getrank();
		obj.put("hot", JSONArray.toJSON(hotlist));
		obj.put("expect", JSONArray.toJSON(expectli));
		obj.put("rank", JSONArray.toJSON(expectrank));

		response.setCharacterEncoding("gbk");
		PrintWriter out = response.getWriter();
		out.print(obj);
		out.close();		

	}

}
