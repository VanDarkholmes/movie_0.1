package com.wz.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.alibaba.fastjson.JSONObject;
import com.wz.bean.Cinema_Bean;
import com.wz.bean.ExpectMovie_Bean;
import com.wz.bean.Movie_Bean;
import com.wz.dao.CinemaDao;
import com.wz.dao.ExpectMovieDao;
import com.wz.dao.MovieDao;
import com.wz.jdbc.DataConnerction;

/**
 * Servlet implementation class MovieInfor
 */
@WebServlet("/MovieInfor")
public class MovieInfor extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public MovieInfor() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		 response.setHeader("Access-Control-Allow-Origin", "*");
		 response.setContentType("text/javascript");	
		 DataConnerction con = new DataConnerction();
		 MovieDao mvdao = new MovieDao(con);
		 ExpectMovieDao exdao = new ExpectMovieDao(con);
		 CinemaDao cidao = new CinemaDao(con);
		 Movie_Bean mv = new Movie_Bean();
		 ExpectMovie_Bean ex = new ExpectMovie_Bean();
		 List<Cinema_Bean> cinema = new ArrayList<Cinema_Bean>();
		 
		 JSONObject obj = new  JSONObject();
		 
		 String Type = request.getParameter("type");
		 //1查电影库 2查预告电影
		 if("1".equals(Type)) {
			 String mvid = request.getParameter("mvid");
			 if(mvid!=null) {
				 mv= mvdao.getMoInfo(mvid);
				 obj.put("motype", Type);
				 obj.put("movie", JSONObject.toJSON(mv));
			 }			 
		 }else if("2".equals(Type)) {
			 String mvid = request.getParameter("mvid");
			 if(mvid!=null) {
				 ex=exdao.getMovie(mvid);
				 obj.put("motype", Type);
				 obj.put("movie", JSONObject.toJSON(ex));
				 
			 }
		 }
		 
		 if(request.getParameter("cinema")!=null) {
			 cinema = cidao.getCinema(request.getParameter("cinema"));
			 obj.put("cinemaID",request.getParameter("cinema"));
		 }else {
			 cinema = cidao.getCinema("1");
			 obj.put("cinemaID", "1");
		 }
		 obj.put("cinema", JSONObject.toJSON(cinema));
		
		response.setCharacterEncoding("gbk");
		PrintWriter out = response.getWriter();
		out.print(obj);
		out.close();	
		 
		 
		 
		 
		 
		 
		 
		 
		 
		 
		 
	}

}
