package com.wz.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.wz.bean.Movie_Bean;
import com.wz.jdbc.DataConnerction;

public class MovieDao {

	private DataConnerction con;
	public MovieDao(DataConnerction con) {
		this.con=con;
		
	}
	public List<Movie_Bean> getMovie(String type,String contry,String page){
		String sql ="SELECT id,title,score,img FROM movie";
		List<Movie_Bean> allData = new ArrayList<Movie_Bean>();
		PreparedStatement pst;
		try {
			if(type!=null&&contry!=null) {
				sql = sql+" WHERE type LIKE \"%"+type+"%\" and contry LIKE \"%"+contry+"%\" ";
			}else if(type!=null){
				sql = sql+" WHERE type LIKE \"%"+type+"%\" ";
			}else if(contry!=null) {
				sql = sql + " WHERE contry LIKE \"%"+contry+"%\" ";
			}
			if(page!=null) {
				sql = sql+" LIMIT ?,18";
				pst = con.getConnection().prepareStatement(sql);
				pst.setInt(1, (Integer.parseInt(page)-1)*15);
			}else {
				pst = con.getConnection().prepareStatement(sql);
			}
			ResultSet rs = pst.executeQuery();
			
			while(rs.next()) {
				Movie_Bean data = new Movie_Bean();
				data.setId(rs.getInt(1));
				data.setTitle(rs.getString(2));
				data.setScore(rs.getDouble(3));
				data.setImg(rs.getString(4));
				allData.add(data);
			}
			rs.close();
			pst.close();
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		

		return allData;
	}
	
	public Movie_Bean getMoInfo(String id) {
		String sql ="SELECT id,score,title,director,actor,img,type,cost,cinetype FROM movie where id=?";
		Movie_Bean movie = new Movie_Bean();
		try {
			PreparedStatement pst = con.getConnection().prepareStatement(sql);
			pst.setInt(1, Integer.parseInt(id));
			ResultSet rs = pst.executeQuery();
			if(rs.first()) {
				movie.setId(rs.getInt(1));
				movie.setScore(rs.getDouble(2));
				movie.setTitle(rs.getString(3));
				movie.setDirector(rs.getString(4));
				movie.setActor(rs.getString(5));
				movie.setImg(rs.getString(6));
				movie.setType(rs.getString(7));
				movie.setCost(rs.getInt(8));
				movie.setCinitype(rs.getString(9));
			}
			rs.close();
			pst.close();
			con.close();
		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return movie;
	}

}
