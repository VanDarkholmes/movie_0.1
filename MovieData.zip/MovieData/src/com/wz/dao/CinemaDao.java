package com.wz.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.wz.bean.Cinema_Bean;

import com.wz.jdbc.DataConnerction;

public class CinemaDao {
	private DataConnerction con;
	public CinemaDao(DataConnerction con) {
		this.con=con;
	}
	
	public List<Cinema_Bean> getCinema(String id) {
		String sql ="SELECT c.id,c.cinema,m.video_room,m.time,m.main_id FROM cinema c INNER JOIN movieshow m ON c.id=m.id WHERE c.id=?";
		List<Cinema_Bean> cinema = new ArrayList<Cinema_Bean>();
		try {
			PreparedStatement pst = con.getConnection().prepareStatement(sql);
			pst.setInt(1, Integer.parseInt(id));
			ResultSet rs = pst.executeQuery();
			while(rs.next()) {
				Cinema_Bean data = new Cinema_Bean();
				data.setId(rs.getInt(1));
				data.setName(rs.getString(2));
				data.setVideo_room(rs.getString(3));
				data.setTime(rs.getString(4));
				data.setMainid(rs.getInt(5));
				cinema.add(data);
			}
			rs.close();
			pst.close();
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		return cinema;
	}
	
	public  Cinema_Bean getSeat(String cinemaid) {
		String sql ="SELECT seat,cinema FROM cinema  where id=?";
		Cinema_Bean seat = new  Cinema_Bean();
		PreparedStatement pst;
		try {
			pst = con.getConnection().prepareStatement(sql);
			pst.setInt(1, Integer.parseInt(cinemaid));
			ResultSet rs = pst.executeQuery();
			if(rs.first()) {
				seat.setSeat(rs.getString(1));
				seat.setName(rs.getString(2));
			}
		
			rs.close();
			pst.close();
			con.close();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return seat;
	}
	public Cinema_Bean getCinema1(String id) {
		String sql ="SELECT video_room FROM  movieshow  WHERE main_id=?";
		Cinema_Bean data = new Cinema_Bean();
		try {
			PreparedStatement pst = con.getConnection().prepareStatement(sql);
			pst.setInt(1, Integer.parseInt(id));
			ResultSet rs = pst.executeQuery();
			if(rs.first()) {
			
				data.setVideo_room(rs.getString(1));
				
			}
			rs.close();
			pst.close();
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		return data;
	}
}
