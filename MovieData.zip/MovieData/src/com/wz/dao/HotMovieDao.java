package com.wz.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.wz.bean.ExpectMovie_Bean;
import com.wz.bean.Movie_Bean;
import com.wz.jdbc.DataConnerction;

public class HotMovieDao {
	private DataConnerction con;
	public HotMovieDao(DataConnerction con) {
		this.con=con;
		
	}
	
	public List<Movie_Bean> GetHotAll(){
		String sql ="SELECT h.id,m.score,h.title,m.director,m.actor,img,type,contry,evaluate,cost FROM hotmv h INNER JOIN movie m on h.id=m.id ";
		try {
			PreparedStatement pst = con.getConnection().prepareStatement(sql);
			ResultSet rs = pst.executeQuery();
			List<Movie_Bean> allData = new ArrayList<Movie_Bean>();
			while(rs.next()) {
				
				Movie_Bean data = new Movie_Bean();
				data.setId(rs.getInt(1));
				data.setScore(rs.getDouble(2));
				data.setTitle(rs.getString(3));
				data.setDirector(rs.getString(4));
				data.setActor(rs.getString(5));
				data.setImg(rs.getString(6));
				data.setType(rs.getString(7));
				data.setContry(rs.getString(8));
				data.setEvaluate(rs.getString(9));
				data.setCost(rs.getInt(10));
				allData.add(data);
			}
			
			rs.close();
			pst.close();
			con.close();
			return allData;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
		
	}
	
	public List<Movie_Bean> getHotMovie(String type,String contry,String page){
		String sql ="SELECT h.id,h.title,m.score,m.img FROM hotmv h INNER JOIN movie m on h.id=m.id ";
		List<Movie_Bean> allData = new ArrayList<Movie_Bean>();
		PreparedStatement pst;
		try {
			if(type!=null&&contry!=null) {
				sql = sql+" WHERE m.type LIKE \"%"+type+"%\" and m.contry LIKE \"%"+contry+"%\" ";
			}else if(type!=null){
				sql = sql+" WHERE m.type LIKE \"%"+type+"%\" ";
			}else if(contry!=null) {
				sql = sql + " WHERE m.contry LIKE \"%"+contry+"%\" ";
			}
			if(page!=null) {
				sql = sql+" LIMIT ?,18";
				pst = con.getConnection().prepareStatement(sql);
				pst.setInt(1, (Integer.parseInt(page)-1)*15);
			}else {
				pst = con.getConnection().prepareStatement(sql);
			}		
			ResultSet rs = pst.executeQuery();
			
			while(rs.next()) {
				Movie_Bean data = new Movie_Bean();
				data.setId(rs.getInt(1));
				data.setTitle(rs.getString(2));
				data.setScore(rs.getDouble(3));
				data.setImg(rs.getString(4));
				allData.add(data);
			}
			rs.close();
			pst.close();
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		

		return allData;
	}

	
	
	
}
