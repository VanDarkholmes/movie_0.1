package com.wz.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.wz.bean.ExpectMovie_Bean;
import com.wz.bean.Movie_Bean;
import com.wz.jdbc.DataConnerction;

public class ExpectMovieDao {
	
		private DataConnerction con;
		public ExpectMovieDao(DataConnerction con) {
			this.con=con;
			
		}
		
		public List<ExpectMovie_Bean> GetExpectAll(){
			String sql ="SELECT id,title,director,actor,duration,img,type,contry,evaluate,time FROM newmv ";
			try {
				PreparedStatement pst = con.getConnection().prepareStatement(sql);
				ResultSet rs = pst.executeQuery();
				List<ExpectMovie_Bean> allData = new ArrayList<ExpectMovie_Bean>();
				while(rs.next()) {				
					ExpectMovie_Bean data = new ExpectMovie_Bean();
					data.setId(rs.getInt(1));
					data.setTitle(rs.getString(2));
					data.setDirector(rs.getString(3));
					data.setActor(rs.getString(4));
					data.setDuration(rs.getString(5));
					data.setImg(rs.getString(6));
					data.setType(rs.getString(7));
					data.setContry(rs.getString(8));
					data.setEvaluate(rs.getString(9));
					data.setTime(rs.getString(10));
					allData.add(data);
				}
				
				rs.close();
				pst.close();
				con.close();
				return allData;
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				return null;
			}
			
		}
		
		public List<ExpectMovie_Bean> getrank(){
			String sql ="SELECT id,title,director,actor,duration,img,type,contry,evaluate,time,people FROM newmv order by people desc";
			try {
				PreparedStatement pst = con.getConnection().prepareStatement(sql);
				ResultSet rs = pst.executeQuery();
				List<ExpectMovie_Bean> allData = new ArrayList<ExpectMovie_Bean>();
				while(rs.next()) {				
					ExpectMovie_Bean data = new ExpectMovie_Bean();
					data.setId(rs.getInt(1));
					data.setTitle(rs.getString(2));
					data.setDirector(rs.getString(3));
					data.setActor(rs.getString(4));
					data.setDuration(rs.getString(5));
					data.setImg(rs.getString(6));
					data.setType(rs.getString(7));
					data.setContry(rs.getString(8));
					data.setEvaluate(rs.getString(9));
					data.setTime(rs.getString(10));
					data.setPeople(rs.getInt(11));
					allData.add(data);
				}
				
				rs.close();
				pst.close();
				con.close();
				return allData;
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				return null;
			}
		}
		
		public List<ExpectMovie_Bean> getExpect(String type,String contry,String page){
			String sql ="SELECT id,title,img,people FROM newmv ";
			List<ExpectMovie_Bean> allData = new ArrayList<ExpectMovie_Bean>();
			PreparedStatement pst;
			try {
				if(type!=null&&contry!=null) {
					sql = sql+" WHERE type LIKE \"%"+type+"%\" and contry LIKE \"%"+contry+"%\" ";
				}else if(type!=null){
					sql = sql+" WHERE type LIKE \"%"+type+"%\" ";
				}else if(contry!=null) {
					sql = sql + " WHERE contry LIKE \"%"+contry+"%\" ";
				}
				if(page!=null) {
					sql = sql+" LIMIT ?,18";
					pst = con.getConnection().prepareStatement(sql);
					pst.setInt(1, (Integer.parseInt(page)-1)*15);
				}else {
					pst = con.getConnection().prepareStatement(sql);
				}
				
				ResultSet rs = pst.executeQuery();
				
				while(rs.next()) {
					ExpectMovie_Bean data = new ExpectMovie_Bean();
					data.setId(rs.getInt(1));
					data.setTitle(rs.getString(2));
					data.setImg(rs.getString(3));
					data.setPeople(rs.getInt(4));
					allData.add(data);
				}
			
				rs.close();
				pst.close();
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			

			return allData;
		}
		
		public ExpectMovie_Bean getMovie(String id) {
			String sql ="SELECT id,people,title,director,actor,img,type FROM newmv where id=?";
			ExpectMovie_Bean movie = new ExpectMovie_Bean();
			try {
				PreparedStatement pst = con.getConnection().prepareStatement(sql);
				pst.setInt(1, Integer.parseInt(id));
				ResultSet rs = pst.executeQuery();
				if(rs.first()) {
					movie.setId(rs.getInt(1));
					movie.setPeople(rs.getInt(2));
					movie.setTitle(rs.getString(3));
					movie.setDirector(rs.getString(4));
					movie.setActor(rs.getString(5));
					movie.setImg(rs.getString(6));
					movie.setType(rs.getString(7));
					
				}
				rs.close();
				pst.close();
				con.close();
			
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return movie;
		}
		
}


