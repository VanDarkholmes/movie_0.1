package com.wz.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.commons.dbutils.QueryRunner;

import com.wz.jdbc.DBUtil;
import com.wz.jdbc.DataConnerction;

public class UserDao {
	private DataConnerction con;
	public UserDao(DataConnerction con) {
		this.con=con;
	}
	
	public boolean findUser(String count,String password) throws SQLException {
		String sql="SELECT count passward FROM counts where count=? and passward=?";
		PreparedStatement pst =con.getConnection().prepareStatement(sql);
		pst.setString(1, count);
		pst.setString(2, password);
		ResultSet rs = pst.executeQuery();	
		boolean flage = rs.first();
		rs.close();
		pst.close();
		con.close();
		return flage;
	}
	
	public int adduser(String user,String password,String email) {
		QueryRunner queryRunner = new QueryRunner();
	Connection connection = DBUtil.getConnection();

	String sql = "insert into counts (count,passward,email) values(?,?,?)";
	Object[] params = {user,password,email};
     
	try { 
		queryRunner.update(connection,sql,params);
		return 1;
	} catch (SQLException e) {
		e.printStackTrace();
		return -1;
	} finally{
		DBUtil.release(null, null, connection);
	}
}
}
