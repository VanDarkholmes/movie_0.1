package com.wz.jdbc;


import java.io.IOException;

import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;


public class DBUtil {
	private static Properties properties;
	
	static{
	
		try {
			
		
			ClassLoader cl = DBUtil.class.getClassLoader();
			InputStream is = cl.getResourceAsStream("db.properties");
			
		
			properties = new Properties();
			properties.load(is);
			
			
			String driver = properties.getProperty("driver");
			Class.forName(driver);
			
		} catch (ClassNotFoundException | IOException e) {
			e.printStackTrace();
		}
	}
	

	public static Connection getConnection(){
		
		String url = properties.getProperty("url");
		String user = properties.getProperty("username");
		String password = properties.getProperty("password");
		Connection connection = null;
		try {
			connection = DriverManager.getConnection(url, user, password);
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return connection;
	}
	

	public static void release(ResultSet resultSet,Statement statement,Connection connection){
	
		if(resultSet != null){
			try {
				resultSet.close(); 
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		if (statement != null) {
			try {
				statement.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		if (connection != null) {
			try {
				connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	
	}
}
